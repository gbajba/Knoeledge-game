/*
https://www.geeksforgeeks.org/socket-programming-in-java/
https://www.javatpoint.com/java-swing
*/

package Group5_GameReportCPIS334_Ch1;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Scanner;

public class Server extends javax.swing.JFrame {

    private ObjectOutputStream output;
    private ObjectInputStream input;
    private ObjectOutputStream output2;
    private ObjectInputStream input2;
    private Socket connection;
    //private Socket connection2;
    private ServerSocket server;
    private int totalClients = 100;
    private int port = 6789;
    //private int port2 = 6790;
    final static String secretKey = "secrete";
    private int sessionNo = 1;
    
    	public static void main(String[] args) {
		    
		Server myServer=new Server();
                myServer.startRunning();
	}

    public Server() {

        initComponents(); // call the function  create the GUI window
        this.setTitle("Knowledge-Game Server"); // set title for the window
        this.setVisible(true);
        status.setVisible(true);
    }

    public void startRunning() {
        try {
            server = new ServerSocket(port, totalClients); // cret new server socket and TCP connection
            while (true) {
                try {
                    status.setText(new Date() + " : Wait for players to join session " + sessionNo);
                    connection = server.accept(); // accept the connection from clinet

                    output = new ObjectOutputStream(connection.getOutputStream()); // object to write in clinet window (send to socket)
                    output.flush();
                    input = new ObjectInputStream(connection.getInputStream()); // object to read from clinet window (from socket)

                    //print in clinet
                    output.writeObject("\n Welcome ");
                    output.writeObject("\n You're player 1 ");
                    output.writeObject("\n Waiting for second client to connect \n");
                    // print in server
                    chatArea.append(new Date() + ": Player 1 joined session " + sessionNo);
                    chatArea.append("\nPlayer 1's IP address" + connection.getInetAddress() + '\n');
                    secondConnection(); //function to wait and connect second clint

                    new Thread(new Runnable() { // thread to play multiple game (many session
                        public void run() {
                            status.setText(new Date() + " : server started to socket 100");
                            try {
                                chatLoop();
                            } catch (IOException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }

                        }
                    }).start();

                } catch (EOFException eofException) {
                }
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }

    }

    private void chatLoop() throws IOException { //read from file and print

        Scanner scanner = null;
        String received = null;

        try {

            scanner = new Scanner(new File("CPIS334QuizCH1.txt"));  // scanner to read from file 
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        }
        output.writeObject("Welcome! Choose the correct option \n");

        while (true) {
            String line = null;
            int score = 0; // score of player1
            int score2 = 0; //score of player 2
            int loopCount = 1;
            try {
                while (loopCount <= 5) {
//					Now second player 1's turn
                    line = scanner.nextLine(); // read the question from file
                    String answer;
                    chatArea.append("\n" + "Player 1's turn");
                    try {
                        output.writeObject(line); // Sending the question to the palyer 1
                        output.flush();
                    } catch (IOException ioException) {
                        chatArea.append("\n\n Unable to Send Message");
                    }
                    try {
                        received = (String) input.readObject(); // Receiving back the answer from player
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
//					chatArea.append("\n" + received);
                    answer = scanner.nextLine(); // read the right answer from file

                    if (answer.equals(received)) { //check answer player is correct
                        score += 1;
                        output.writeObject("\nAnswer : Correct \tScore = " + score); // print the score in player window

                        if ((score - score2 > 2)) { // check if it is two score difference betwwn players
                            // close the connection
                            System.out.println("Closing this connection.");
                            this.connection.close();
                            System.out.println("Connection closed");

                            //close input and output function
                            input.close();
                            output.close();
                            input2.close();
                            output2.close();
                            break;
                        }

                        chatArea.append("\n" + "Player 1 answered CORRECT \tScore = " + score);
                        output2.writeObject("\nPlayer 1 answered CORRECTLY");
                    } else {
                        System.out.println("Answer ==>> " + answer + " recieved ==>> " + received + " score ==>> " + score);
                        output.writeObject("\nYour answer is Wrong");
                        chatArea.append("\n" + "Player 1's answer is Wrong");
                        output2.writeObject("\nPlayer 1 answered WRONG\n");
                    }

//					Now second player 2's turn
                    line = scanner.nextLine();
                    chatArea.append("\n" + "Player 2's turn");
                    try {
                        output2.writeObject(line); // Sending the question to the palyer 2
                        output2.flush();
                    } catch (IOException ioException) {
                        chatArea.append("\n\n Unable to Send Message");
                    }
                    try {
                        received = (String) input2.readObject(); // Receiving back the answer from player 2
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    answer = scanner.nextLine();

                    if (answer.equals(received)) {
                        score2 += 1;
                        output2.writeObject("\nAnswer : Correct \tScore = " + score2);
                        if ((score2 - score > 2)) {
                            break;
                        }

                        output.writeObject("\nPlayer 2 answered CORRECTLY");
                        chatArea.append("\n" + "Player 2 answered CORRECT \tScore = " + score2);
                    } else {
                        System.out.println("Answer ==>> " + answer + " recieved ==>> " + received + " score ==>> " + score2);
                        output2.writeObject("\nYour answer is Wrong");
                        chatArea.append("\n" + "Player 2's answer is Wrong\n");

                        output.writeObject("\nPlayer 2 answered WRONG\n");
                    }

                    loopCount++;
                }

                if (score > score2) { // Player 1 won
                    output2.writeObject("\nPlayer 1 won..... Good luck for the next time \n");
                    output.writeObject("\nCongratulations you won\n");
                    chatArea.append("\n" + "Player 1 WON");
                } else if (score2 > score) {// Player 2 won
                    output.writeObject("\nPlayer 2 won..... Good luck for the next time \n");
                    output2.writeObject("\nCongratulations you won\n");
                    chatArea.append("\n" + "Player 2 WON");
                } else { // Tied Both have same number of correct answers
                    output.writeObject("Game is over no winner !\n");
                    output2.writeObject("Game is over no winner !\n");
                    chatArea.append("\n" + "DRAW");
                }

                // close the connection
                System.out.println("Closing this connection.");
                this.connection.close();
                System.out.println("Connection closed");

                //close input and output function
                input.close();
                output.close();
                input2.close();
                output2.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public boolean secondConnection() throws IOException { // clint 2 connecting

        try {
            System.out.println("Trying to connect to second one");
            chatArea.append("\n Waiting for second to Connect\n");
            connection = server.accept(); // connected to server socket

            output2 = new ObjectOutputStream(connection.getOutputStream());
            output2.flush();
            input2 = new ObjectInputStream(connection.getInputStream());

            output2.writeObject("Welcome");
            output2.writeObject("\nYou're player 2");
            output.writeObject("Player 2 joined\n");
            chatArea.append(new Date() + ": Player 2 joined session " + sessionNo);
            chatArea.append("\nPlayer 2's IP address" + connection.getInetAddress() + "\n\n");
            chatArea.append(new Date() + ": Start a thread for session " + sessionNo++ + '\n');
            return true;

        } catch (EOFException eofException) {
            return false;
        }

//			}
    }

    @SuppressWarnings("unchecked")
    private void initComponents() { // GUI items

        jPanel1 = new javax.swing.JPanel(); // the main panel
        jScrollPane1 = new javax.swing.JScrollPane();
        chatArea = new javax.swing.JTextArea(); // window to recive messges
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        status = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); // close the program
        setBackground(new java.awt.Color(51, 255, 204));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setForeground(new java.awt.Color(102, 255, 204));

        jPanel1.setBackground(new java.awt.Color(242, 245, 250)); // Background color for the main screen
        jPanel1.setLayout(null);

        chatArea.setColumns(20);
        chatArea.setRows(5);
        jScrollPane1.setViewportView(chatArea);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 90, 465, 250);
        status.setForeground(new java.awt.Color(15, 15, 15));
        status.setText("...");
        jPanel1.add(status);
        status.setBounds(10, 60, 300, 40);

        jLabel2.setFont(new java.awt.Font("Myriad Pro", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(15, 15, 15));
        jLabel2.setText("Server");
        jLabel2.setToolTipText("");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(175, 10, 190, 60);

        jLabel1.setBackground(new java.awt.Color(153, 255, 204));
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 35, 460, 410);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
                jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 500,
                javax.swing.GroupLayout.PREFERRED_SIZE));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup().addComponent(jPanel1,
                                javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)));

        setSize(new java.awt.Dimension(500, 427));
        setLocationRelativeTo(null);
    }

    private javax.swing.JTextArea chatArea;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel status;

}

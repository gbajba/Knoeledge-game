package Group5_GameReportCPIS334_Ch1;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Date;
import javax.swing.JOptionPane;

public class Client extends javax.swing.JFrame {

    private ObjectOutputStream output;
    private ObjectInputStream input;

    private String message = "";
    private String serverIP;
    String Line = null;
    private Socket connection;
    private int port = 6789;
    
        public static void main(String[] args) 
    {
        Client client=new Client("127.0.0.1");
        client.startRunning();
    }

    public Client(String s) { // main constructer

        initComponents(); // call the GUI function

        this.setTitle("Knowledge-Game Client");
        this.setVisible(true);
        status.setVisible(true);
        serverIP = s;
    }

    @SuppressWarnings("unchecked")
    private void initComponents() { //function to creet window

        jPanel1 = new javax.swing.JPanel(); // main panel
        //creat a choises button 
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        chatArea = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        status = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); //exit window
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 51)); // Background color for the main screen
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(null);

        //set A button properties
        jButton1.setBackground(new java.awt.Color(245, 247, 250));
        jButton1.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton1.setText("A");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
//set B button properties
        jButton2.setBackground(new java.awt.Color(245, 247, 250));
        jButton2.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton2.setText("B");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
//set C button properties
        jButton3.setBackground(new java.awt.Color(245, 247, 250));
        jButton3.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton3.setText("C");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
//set D button properties
        jButton4.setBackground(new java.awt.Color(245, 247, 250));
        jButton4.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jButton4.setText("D");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        //add buttons to panel
        jPanel1.add(jButton1);
        jPanel1.add(jButton2);
        jPanel1.add(jButton3);
        jPanel1.add(jButton4);
        jButton1.setBounds(70, 350, 55, 30);
        jButton2.setBounds(170, 350, 55, 30);
        jButton3.setBounds(270, 350, 55, 30);
        jButton4.setBounds(370, 350, 55, 30);
        chatArea.setColumns(20);
        chatArea.setRows(5);
        jScrollPane1.setViewportView(chatArea);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 90, 465, 250);

        jLabel2.setFont(new java.awt.Font("Myriad Pro", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Client");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(175, 10, 190, 60);

        status.setForeground(new java.awt.Color(255, 255, 255));
        status.setText("...");
        jPanel1.add(status);
        status.setBounds(10, 50, 300, 40);
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 400, 400);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
                jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
                jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE));

        setSize(new java.awt.Dimension(508, 441));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed

        sendingMessagetoClient("A");//send anser A if player press A button
    }// GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed

        sendingMessagetoClient("B");//send anser B if player press B button
       
    }// GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed

        sendingMessagetoClient("C");//send anser C if player press C button
     
    }// GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed

        sendingMessagetoClient("D");//send anser D if player press D button
        
    }// GEN-LAST:event_jButton1ActionPerformed

    public void startRunning() { // run the clint 
        try {
            status.setText("Trying to Connect ...");
            try {
                connection = new Socket(InetAddress.getByName(serverIP), port); //new socket connecting with server
            } catch (IOException ioEception) {
                JOptionPane.showMessageDialog(null, "Server not running", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            status.setText(new Date() + " : Connected to: " + connection.getInetAddress().getHostName());

            output = new ObjectOutputStream(connection.getOutputStream()); 
            output.flush();
            input = new ObjectInputStream(connection.getInputStream());

            chatLoop();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void chatLoop() throws IOException {

        while (true) {

            try {
                System.out.println("Recieving");
                message = (String) input.readObject();

                StringTokenizer multiTokenizer = new StringTokenizer(message, ":-");//split the msg with :-

                while (multiTokenizer.hasMoreTokens()) {
                    chatArea.append("\n" + multiTokenizer.nextToken()); // write every split in new line
                }

                chatArea.append("");

                System.out.println(message);
            } catch (ClassNotFoundException classNotFoundException) {
            }

            if (message.equals("")) {
                System.out.println(input.readUTF());

                System.out.println("Closing this connection : " + connection);
                connection.close();
                System.out.println("Connection closed");
                break;

            }

        }

//		scn.close(); 
        input.close();
        output.close();

    }

    private void sendingMessagetoClient(String message) {
        try {
            chatArea.append("\nME(Client) - " + message); // display my answer
            output.writeObject(message);
            output.flush();
        } catch (IOException ioException) {
            chatArea.append("\n Unable to Send Message");
        }
    }

    private javax.swing.JTextArea chatArea;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    //private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel status;
}
